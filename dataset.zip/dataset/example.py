import pandas as pd

def main():
    df = pd.read_csv("volusia-parcel-aadt.csv")
    print(df.head(15))
    return

if __name__ == "__main__":
    main()